﻿<html>
<head>
	<title>LOGIN</title>
</head>
<body>
	

	<br/><br/><br/>
	<h1 align=center>사이트 이름</h1><br/><br/><br/><br/><br/><br/><br/><br/>
	<form action="login2.php" method="POST">
		<table width=800 border=3 align=center>
		<tr>
			<td colspan=10 align=center>LOGIN
		<tr>
			<td>아이디	
			<td><input type=text name=id size=10 maxlength=20>

		<tr>
			<td>비밀번호
			<td><input type=password name=pw size=10 maxlength=20>
		<tr>
			<td bgcolor=#eeeeee colspan=2 align=center>
			<input type=submit value="로그인하기">
		
	</form>
	<br/>
	<form action="sign.php" method="POST">
		<input type=submit value="회원가입">
	</form>

	

</body>
</html>