﻿<?
	include "dbconn.php";
?>
<html>
<head>
<title>맛집공유사이트</title>
<meta http-equiv="content-type" content="text/html; charset=euc-kr">
<style>
A:link {COLOR: black; TEXT-DECORATION: none}
A:visited {COLOR: black; TEXT-DECORATION: none}
A:hover {COLOR: red; TEXT-DECORATION: underline }
        ul, li{
            list-style: none;
        }
        ul.menu{
            float: right;
        }
        ul.menu li{
            float: left;
            margin-right: 10px;
        }
        ul.menu li ul{
            display: none;
        }
        ul.menu li:hover a{
            background-color: #ccc;
        }
        ul.menu li:hover ul{
            display: block;
            position: absolute;
            top: 18px;
            right: 0;
        }
</style>
</head>
<body>
	<font face="돋움">
	<table width="1250" border="0" align="center" cellspacing="0" bgcolor="#FFE5C2" style="border:0px #333333 solid; border-top-width:3px;">
	<div class="wrap">
	<header>
	<td align="center"><br/>
	<font style="font-size:25pt;font-weight:bolder;">
		<h1>SHAR<font color="red">E</font>:AT</h1>
	</font>
	<font style="font-size:15pt;font-weight:bolder;">
		<a id="logo" href="./list.php"> 맛집공유 </a >
		<span class="right" style="padding: 30px 10px;">
		<a href="./logout.php" target="_blank">로그아웃</a> 
		<a href="intro.html" target="_blank">사이트소개</a>
	</font>
		</span>
	<br/>
	
<?
	echo "안녕하세요 ".$_SESSION['id']."님! 환영합니다.";
?>
</td>
</header>
</table>
	<table width="500" border="0" align="center" cellpadding="5" cellspacing="0" bgcolor="#FAECC5" style="border:0px #333333 solid;">
	<td align="center">
	<article class="menu"><font size="5">Menu</font></div></td>
	</table>
	<br>
	<table width="100%" border=0 cellspacing="0" cellpadding="0"">
	<tr><th height="379">
	<img src="img/치킨.png"/>
	<img src="img/피자.png"/>
	<img src="img/족발.png"/><br/>
	<img src="img/한식.png"/>
	<img src="img/일식.png"/>
	<img src="img/중국집.png"/><br/>
	<img src="img/분식.png"/>
	<img src="img/야식.png"/>
	<img src="img/프랜차이즈.png"/>
	</th></tr></table>

	
	<?php
		
		$sum = 0;
		$todayc = date("Y-m-d");
		$sql = "select * from counter where last_date = '.$todayc.'";
		$result = mysqli_query($connect, $sql);
		$row = mysqli_fetch_assoc($result);
	
		if(!$row) {
			$sql1 = "insert into counter(last_date, visited) values ('.$todayc.', 1)";
			mysqli_query($connect, $sql1);
		}
		else {
			$sql2 = "update counter set visited=visited+1 where last_date='.$todayc.'";
			mysqli_query($connect, $sql2);
		}

		$sql = "select * from counter where last_date = '.$todayc.'";
		$result = mysqli_query($connect, $sql);
		$row = mysqli_fetch_assoc($result);
		$visited = $row['visited'];
		$sqlt = "select * from counter";
		$resultt = mysqli_query($connect, $sqlt);
	
		while($rowt=mysqli_fetch_assoc($resultt)){
			$sum += $rowt['visited'];
		}
	?>		

	<table>
		<tr>
			<td bgcolor=#EEEEEE> 전체 <?=number_format($sum)?></td> 
			<td bgcolor=#EEEEEE> 오늘 <?=number_format($visited)?></td>
		</tr>
	</table>
	<footer>
	<div id="copyright">
	Copyright [채전방] 2016 Chae.Jeon.Bang. All rights reserved
	</div>
	</footer>
</font>
</body>
</html>
	
