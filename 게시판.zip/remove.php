﻿<?php
	include 'dbconn.php';

	//$_GET['num']이 있어야만 글삭제가 가능함.
	if(isset($_GET['num'])) {
		$num = $_GET['num'];
	}
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8" />
	<title> 맛집 공유 게시판 </title>
	<link rel="stylesheet" href="./css/normalize.css" />
	<link rel="stylesheet" href="./css/board.css" />
</head>
<body>
	<article class="boardArticle">
		<h3>자유게시판 글삭제</h3>
		<?php
			if(isset($num)) {
				$sql = 'select count(num) as cnt from free where num = '.$num;
				$result = mysqli_query($connect, $sql);
				$row = mysqli_fetch_assoc($result);
				if(empty($row['cnt'])) {
		?>
		<script>
			alert('글이 존재하지 않습니다.');
			history.back();
		</script>
		<?php
			exit;
				}
				
				$sql = 'select subject from free where num = '.$num;
				$result = mysqli_query($connect, $sql);
				$row = mysqli_fetch_assoc($result);
		?>
		<div id="boardDelete">
			<form action="./remove_update.php" method="post">
				<input type="hidden" name="num" value="<?php echo $num?>">
				<table>
					<caption class="readHide">자유게시판 글삭제</caption>
					<thead>
						<tr>
							<th scope="col" colspan="2">글삭제</th>
						</tr>
					</thead>
					<tbody>
						<tr>
							<th scope="row">글 제목</th>
							<td><?php echo $row['subject']?></td>
						</tr>
						<tr>
							<th scope="row"><label for="password">비밀번호</label></th>
							<td><input type="password" name="password" id="password"></td>
						</tr>
					</tbody>
				</table>

				<div class="btnSet">
					<button type="submit" class="btnSubmit btn">삭제</button>
					<a href="./list.php" class="btnList btn">목록</a>
				</div>
			</form>
		</div>
	<?php
		//$num이 없다면 삭제 실패
		} else {
	?>
		<script>
			alert('정상적인 경로를 이용해주세요.');
			history.back();
		</script>
	<?php
			exit;
		}
	?>
	</article>
</body>
</html>