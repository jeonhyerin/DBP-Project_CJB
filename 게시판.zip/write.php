﻿<?php
	include 'dbconn.php';

	//$_GET['num']이 있을 때만 $num 선언
	if(isset($_GET['num'])) {
		$num = $_GET['num'];
	}
		 
	if(isset($num)) {
		$sql = 'select * from free where num = '.$num;
		$result = mysqli_query($connect, $sql);
		$row = mysqli_fetch_assoc($result);
	}
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="euc-kr" />
	<title> 맛집 공유 게시판 </title>
	<link rel="stylesheet" href="./css/normalize.css" />
	<link rel="stylesheet" href="./css/board.css" />
</head>
<body>
	<article class="boardArticle">
		<h3> 맛집 공유 게시판 글쓰기</h3>
		<div id="boardWrite">
			<form action="./write_update.php" method="post">
				<?php
				if(isset($num)) {
					echo '<input type="hidden" name="num" value="' . $num . '">';
				}
				?>
				<table id="boardWrite">
					<caption class="readHide">맛집 공유 게시판 글쓰기</caption>
					<tbody>
						<tr>
							<th scope="row"><label for="name">이름</label></th>
							<td class="name">
								<?php
								if(isset($num)) {
									echo $row['name'];
								} else { ?>
									<input type="text" name="name" id="name">
								<?php } ?>
							</td>
						</tr>
						<tr>
							<th scope="row"><label for="pw">비밀번호</label></th>
							<td class="password"><input type="password" name="pw" id="pw"></td>
						</tr>
						<tr>
							<th scope="row"><label for="subject">제목</label></th>
							<td class="subject"><input type="text" name="subject" id="subject" value="<?php echo isset($row['subject'])?$row['subject']:null?>"></td>
						</tr>
						<tr>
							<th scope="row"><label for="content">내용</label></th>
							<td class="content"><textarea cols="50" rows="30" name="content" id="content"><?php echo isset($row['content'])?$row['content']:null?></textarea></td>
						</tr>
						<tr>
							<td align=center> 파일첨부1 : <input type="file" name="upfile[]">
							<?php
								if($row['file_name_0']) {
									echo "<b>{$row['file_name_0']}</b> 파일이 등록되어 있습니다.";
								}
							?>
							 </td>		
						</tr>
						<tr>
							<td align=center> 파일첨부2 : <input type="file" name="upfile[]">
							<?php
								if($row['file_name_1']) {
									echo "<b>{$row['file_name_1']}</b> 파일이 등록되어 있습니다.";
								}
							?>
							 </td>		
						</tr>
						<tr>
							<td align=center> 파일첨부3 : <input type="file" name="upfile[]">
							<?php
								if($row['file_name_2']) {
									echo "<b>{$row['file_name_2']}</b> 파일이 등록되어 있습니다.";
								}
							?>
							 </td>		
						</tr>
					</tbody>
				</table>
				<div class="btnSet">
					<button type="submit" class="btnSubmit btn">
						<?php echo isset($num)?'수정':'작성'?>
					</button>
					<a href="list.php" class="btnList btn">목록</a>
				</div>
			</form>
		</div>
	</article>
</body>
</html>