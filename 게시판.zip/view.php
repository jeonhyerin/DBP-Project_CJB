﻿<?php
	include 'dbconn.php';
	$num = $_GET['num'];

	if(!empty($num) && empty($_COOKIE['free_' . $num])) {
		$sql = 'UPDATE free SET hit=hit+1 WHERE num ='.$num;
		$result = mysqli_query($connect, $sql); 
		if(empty($result)) {
			?>
			<script>
				alert('오류가 발생했습니다.');
				history.back();
			</script>
			<?php 
		}
		else {
			setcookie('free_' . $num, TRUE, time() + (60 * 60 * 24), '/');
		}
	}
	$sql = 'SELECT * FROM free WHERE num = '.$num;
	$result = mysqli_query($connect, $sql);
	$row = mysqli_fetch_assoc($result);
	
		
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8" />
	<title> 맛집 공유 게시판</title>
	<link rel="stylesheet" href="./css/normalize.css" />
	<link rel="stylesheet" href="./css/board.css" />
	<script>
	function del(href)
	{
		if(confirm("한번 삭제한 자료는 복구할 방법이 없습니다.\n\n 정말 삭제하시겠습니까?"))
		{
			document.location.href = href;
		}
	}
	</script>
</head>
<body>
	<article class="boardArticle">
		<h3> 맛집 공유 게시판 글쓰기</h3>
		<div id="boardView">
			<h3 id="boardTitle"><?php echo $row['subject']?></h3>
			<div id="boardInfo">
				<span id="boardID">작성자: <?php echo $row['id']?></span>
				<span id="boardDate">작성일: <?php echo $row['regist_day']?></span>
				<span id="boardHit">조회: <?php echo $row['hit']?></span>
			</div>
			<div id="boardContent"><?php echo $row['content']?>
			</div>
			<div class="btnSet">
				<a href="./write.php?bno=<?=$num?>">수정</a>
				<a href="javascript:del('./remove.php?bno=<?=$num?>')">삭제</a>
				<a href="./list.php?bno=<?=$num?>">목록</a>
			</div>
		<div id="boardComment">
			<?php include './comment.php'; ?>
		</div>
		</div>
	</article>
</body>
</html>