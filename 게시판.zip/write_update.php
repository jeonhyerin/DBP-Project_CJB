﻿<?php
	include 'dbconn.php';

	//$_POST['num']이 있을 때만 $num 선언
	if(isset($_POST['num'])) {
		$num = $_POST['num'];
	}

	//num이 없다면(글 쓰기라면) 변수 선언
	if(empty($num)) {
		$name = $_POST['name'];
		$regist_day = date('Y-m-d H:i:s');
	}

	//항상 변수 선언
	$password = $_POST['password'];
	$subject = $_POST['subject'];
	$content = $_POST['content'];

	

	//글 수정
	if(isset($num)) {
		//수정 할 글의 비밀번호가 입력된 비밀번호와 맞는지 체크
		$sql = 'select count(password) as cnt from free where pw=password("'.$password.'") and num = '.$num;
		$result = mysqli_query($connect, $sql);
		$row = mysqli_fetch_assoc($result);
	
	
		if($row['cnt']) //비밀번호가 맞다면 업데이트 쿼리 작성
		{
			$sql = 'update free set name='.$name.', subject='.$subject.', content='.$content.' where num='.$num;
			$msgState = '수정';		
		}
		else {	 //틀리다면 메시지 출력 후 이전화면으로
			$msg = '비밀번호가 맞지 않습니다.';
	?>
	<script>
		alert("<?php echo $msg?>");
		history.back();
	</script>
	<?php
		exit;
	}
	
	//글 등록
	} 
	else {
		$sql = 'insert into free (num, subject, content, regist_day, hit, name, password) 
		values(null, "'.$subject.'", "'.$content.'", '.$regist_day.', 0, '.$name.', password('.$password.'))';
		$msgState = '등록';
	}

	//메시지가 없다면 (오류가 없다면)
	if(empty($msg)) {
		$result = mysqli_query($connect, $sql);
	
		//쿼리가 정상 실행 됐다면,
		if($result) {
			$msg = '정상적으로 글이 ' . $msgState . '되었습니다.';
			
			if(empty($num)) {
				$num = mysqli_insert_id($connect);
			}
			$replaceURL = './view.php?bno=' . $num;
		} 
		else {
			$msg = '글을 '.$msgState.'하지 못했습니다.';
		?>
		<script>
			alert("<?php echo $msg?>");
			history.back();
		</script>
	<?php
		exit;
	}
}

?>
<script>
	alert("<?php echo $msg?>");
	location.replace("<?php echo $replaceURL?>");
</script>