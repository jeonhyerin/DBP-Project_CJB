﻿<?
	include "dbcon.php";
?>
<html>
<head>
<title>맛집공유사이트</title>
<meta http-equiv="content-type" content="text/html; charset=euc-kr">
</head>
<body>
	<div class="wrap">
	<header>
		<a id="logo" href="./list.php"> 맛집공유 </a>
		<span class="right" style="padding: 30px 10px;">
		<a href="login.html" target="_self">로그인</a> |
		<a href="signup.html" target="_blank">회원가입</a>
		</span>
	</header>
	
	<article class="menu">메뉴</div>
	<img src="img/치킨.png"/>
	<img src="img/피자.png"/>
	<img src="img/족발.png"/>
	<img src="img/한식.png"/>
	<img src="img/일식.png"/>
	<img src="img/중국집.png"/>
	<img src="img/분식.png"/>
	<img src="img/야식.png"/>
	<img src="img/프랜차이즈.png"/>
	</aside>
	<?php
		
		$sum = 0;
		$todayc = date("Y-m-d");
		$sql = "select * from counter where last_date = '.$todayc.'";
		$result = mysqli_query($connect, $sql);
		$row = mysqli_fetch_assoc($result);
	
		if(!$row) {
			$sql1 = "insert into counter(last_date, visited) values ('.$todayc.', 1)";
			mysqli_query($connect, $sql1);
		}
		else {
			$sql2 = "update counter set visited=visited+1 where last_date='.$todayc.'";
			mysqli_query($connect, $sql2);
		}

		$sql = "select * from counter where last_date = '.$todayc.'";
		$result = mysqli_query($connect, $sql);
		$row = mysqli_fetch_assoc($result);
		$visited = $row['visited'];
		$sqlt = "select * from counter";
		$resultt = mysqli_query($connect, $sqlt);
	
		while($rowt=mysqli_fetch_assoc($resultt)){
			$sum += $rowt['visited'];
		}
	?>
	<table>
		<tr>
			<td bgcolor=#EEEEEE> 전체 <?=number_format($sum)?></td> 
			<td bgcolor=#EEEEEE> 오늘 <?=number_format($visited)?></td>
		</tr>
	</table>
	<footer>
	<div id="copyright">
	Copyright [채전방] 2016 Chae.Jeon.Bang. All rights reserved
	</div>
	</footer>
</body>
</html>
	
