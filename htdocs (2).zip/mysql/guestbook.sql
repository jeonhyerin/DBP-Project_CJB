CREATE TABLE IF NOT EXISTS guestbook(
	rowid int(11) NOT NULL auto_increment,
	name varchar(30) default NULL,
	email varchar(100) default NULL,
	content text,
	password varchar(50) default NULL,
	input_date varchar(30) default NULL,
	hostinfo varchar(30) default NULL,
	edit_date varchar(30) default NULL,
	PRIMARY KEY (rowid)
);