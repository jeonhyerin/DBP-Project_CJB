﻿create table counter(
rowid int(11) not null auto_increment,
last_date datetime not null,
visited int unsigned not null
);