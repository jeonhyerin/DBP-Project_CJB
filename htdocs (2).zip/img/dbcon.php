<?

$db_hostname="localhost";
$db_username="pj";
$db_password="1234";
$dbname="pj_db";

?>
