﻿<?
	include "dbcon.php";

	if ($name=="" || $email=="" || $password=="") {
			echo "
			<script>
			alert('필수입력란을 정확히 입력하세요!');
			history.back();
			</script>
			";
			die;
}

	$sql = "insert into guestbook (name,email,content,password,input_date,hostinfo
	) values ('$name','$email',".str_replace("'","&acute;",$content)."'
	,MD5('$password'),now(),'$REMOTE_ADDR')";
	$res = mysqli_query($sql);

	$affected_rows = mysqli_affected_rows();

	if($affected_rows>0) {
		echo "
		<script>
		alert('등록되었습니다.');
		location.replace('form_list.php');
		</script>
		";
	} else {
		echo "
		<script>
		alert('데이터베이스서버의 오류 또는 회원필드 오류로 인하여 등록 실패하였습니다.');
		history.back();
		</script>
		";
	}
	
?>
	