<?
	include "dbcon.php";

	//���� �ʱ�ȭ
	$ipp=10;
	$ten=10;
	if ($page<=0) $page = 1;
	if ($startpage<=0) $startpaage = 1;

	//���� �������� ���� ���ڵ� �˻�
	$startrow = ($page - 1) * $ipp;

	//�˻��� ����
	if ($keyword!="") {
		$sql_where = " where $keyfield like '%$keyword%' ";
	}//if

	//��ü �� �� ���
	$total_sql = "select count(*) from guestbook";
	$total_sql.= $sql_where;
	$res = mysqli_query($connect, $total_sql);
	if ($res) $rs = mysqli_fetch_row($res);
	
	$total_count = $rs[0];
	$totpage = ceil($total_count/$ipp);

	//���� �������� ����� ���ڵ� ����
	$list_sql = "select * from guestbook";
	$list_sql.= $sql_where;
	$list_sql.= "order by input_date desc";
	$list_sql.= "limit $startrow, $ipp";
	$res = mysqli_query($connect, $list_sql);
?>

<html>
<head>
<title></title>
<meta http-equiv="Content-Type" content="text/html; charset=euc-kr">
</head>

<body leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<br>
<br>
<table width="650" border="0" align="center" cellpadding="5" cellspacing="0" bgcolor="#CFEAEB" style="border:0px #333333 solid; border-top-width:3px;">
	<tr>
	<td><b>�����</b></td>
	<td align="right">
		[<a href="add_form.php">���</a>]
	</td>
	</tr>
</table>
<table width="650" height="24" border="0" align="center" cellpadding="5" cellspacing="0">
	<tr>
	<td>&nbsp;</td>
	<td align="right">
		Total <? echo number_format($totpage);?>pages
		/<? echo number_format($total_count);?>items
	</td>
	</tr>
</table>

<?
if ($res) {
	while ($rs = mysqli_fetch_array($res)) {
?>

<table width="650" border="0" align="center" cellpadding="5" cellspacing="1" bgcolor="#CCCCCC" style="border:0px #999999 solid;border-bottom-width:1px;">
	<tr>
	<td width="70" align="center" bgcolor="#CFEAEB">��ȣ</td><td width="150" bgcolor="#E8E8E8">
	<?echo $rs[rowid];?>
	</td>
	<td width="70" align="center" bgcolor="#CFEAEB">�����</td><td width="200" bgcolor="#E8E8E8">
	<? echo substr($rs[input_date],0,10);?>
	from <? echo $rs[hostinfo];?>
	</td>
	<td align="center" nowrap bgcolor="#E8E8E8">
	[<a href="auth_form.php?mode=edit&rowid=<? echo $rs[rowid];?>">����</a>]
	[<a href="auth_form.php?mode=del&rowid=<? echo $rs[rowid];?>"����</a>]
	</td>
	</tr>
	<tr>
	<td align="center" bgcolor="#CFEAEB">�̸�</td>
	<td bgcolor="#E8E8E8">
	<? echo $rs[name];?>
	</td>
	<td align="center" bgcolor="#CFEAEB">�̸���</td><td colspan="2" bgcolor="#E8E8E8">
	<a href="mailto:<? echo $rs[email];?>"><? echo $rs[email];?>
	</a>
	</td>
	</tr>
	<tr valign="top" bgcolor="#E8E8E8">
	 <td height="100" colspan="5">
		 <table width="640" border="0" cellspacing="0" cellpadding="0">
		<tr>
		 <td width="640">
		<? echo nl2br($rs[content]);?>
		  </td>
		 </tr>
		</table></td>
	 </tr>
	</table>
<br>

<?
	}//while
}//if
?>
	
<table width="650" height="40" border="0" align="center" cellpadding="5" cellspacing="0" bgcolor="#CFEAEB" style="border:0px #333333 solid;border-bottom-witdh:3px;">
	<tr>
	<td>
<form name="page_form" method="post" action="" style="margin:0px;">
	<table border="0" cellpadding="0" cellspacing="0">
	<tr valign="bottom">
	<td style="color:#333333;font-size:12px;">
<span style="font-weight:bold;"> Go to Page:</span>

&nbsp;&nbsp;

<? if($startpage>1) { ?>
<a style="cursor:hand;color:#333333;font-weight:;font-size:12px;"onClick="search_form.startpage.value='<? echo $startpage-$ten;?>
search_form.page.value='<? echo $startpage=$ten;?>';
search_form.submit();"
>

��Prev
</a>
<? }//if?>

<select name="page" id="page" onChange="form2form('page',this.form.name,'search_form');
search_form.submit();
">
<?
$endpage = $startpage + $ten - 1;
if($endpage>$totpage) $endpage = $totpage;

for ($i=$startpage;$i<=$endpage;$i++) {?>
	<option vaule="<? echo $i;?>"
	<? if ($page==$i) echo "selected";?>>
	<? echo $i;?>
	</option>
<? }//for ?>

</select>

<? if ($endpage<$totpage) { ?>
<a style="cursor:hand;color:#333333;font-weight:;font-size:12px;"
onClick="search_form.startpage.value='<? echo $startpage+$ten;?>';
search_form.page.value='<? echo $startpage+$ten;?>';
search_form.submit();">Next��</a>
<? }//if?>
	&nbsp;></td>
</tr>
	</table>
	</form>
	</td>
	<td align="right">
<form name="search_form" id="search_form" action="<? echo $PHP_SELF;?>" method="get" style="margin:0px;">

	<table border="0" cellspacing="0" cellpadding="0">
	<tr>
	<td>

	<input name="page" id="page" type="hidden" value="1">
	<input name="startpage" id="startpage" type="hidden" value="1">
	
	<select name="keyfield" id="keyfield">
	<option value="name" <? if($keyfield=="name") echo "selected";?>>�̸�</option>
	<option value="email" <? if($keyfield=="email") echo "selected";?>>�̸���</option>
	<option value="content" <? if($keyfield=="content") echo "selected";?>>����</option>
	</select>
	</td>
	<td>
	<input name="keyword" id="keyword" type="text" value"<? echo $keyword;?>" size="12">
	</td>
	<td>
	<input type="submit" name="Submit" value="Search">
	</td>
	</tr>
	</table>
	
	</form>
	</td>
	</tr>
	</table>
	
	<script>
	fuction form2form(name,from,to) {
		var fromObj, toObj;
		fromObj = eval("document."+from+"."name);
		toObj =  eval("document"+to+"."+name);
		toObj.value = fromObj.value;
	}
</script>
</body>
</html>
