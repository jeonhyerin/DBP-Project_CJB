<?

	$connect = mysqli_connect("localhost", "pj", "1234", "pj_db");

	if(!$connect) {
		echo "Error: Unable to connect to MySQL." . PHP_EOL;
		exit;
	}

?>