<?
	include "dbcon.php";

	$sql = "select * from guestbook where rowid='$rowid'";
	$res = mysqli_query($sql);
	if ($res) $rs = mysqli_fetch_array($res);

	//�� ��ȣ�� Ȯ���Ͽ� ���� �ο�
	if ($password!="" && $rs[password]==md5($password)) {
		$session_auth=$rowid;
	} else {
		$session_auth="";
		echo "
		<script>
		alert('��ȣ�� �ùٸ��� �ʽ��ϴ�.');
		history.back();
		</script>
		";
		die;
	}
?>


<html>
<head>
<title></title>
<meta http-equiv="Content-Type" content="text/html; charset=euc-kr">
</head>

<body leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<br>
<br>
<table width="500" border="0" align="center" cellpadding="5" cellspacing="0" bgcolor="#CFEAEB" style"border:0px #333333 solid; border-top-width:3px;">
	<tr>
		<td><b>����� ������</b></td>
		<td align="right">
			[<a href="form_list.php">���</a>
			</td>
		<tr>
</table>
<br>
<table width="500" border="0" align="center" cellpadding="5" cellspacing="0">
	<tr>
	<td align="center">
		��Ȯ�� �Է��Ͻ� �� ����ϼ���! &quot;<font color="#FF0000">*</font>&quot;�� �ʼ� �Է»����Դϴ�.</td>
	</tr>
</table>
<br>

<form name="edit_form" id="edit_form" action="edit.php" style="margin:0px;" onSubmit="return chectForm(this)">

	<table width="500" border="0" align="center" cellpadding="5" cellspacing="1">
	<tr>
		<td width="100" bgcolor="#CFEAEB"><font color="#FF0000">*</font>�̸�</td>
		<td bgcolor="#E8E8E8">

		<input name="name" id="name" type="text" value="<? echo $rs[name];?>" size="20">
		��) ä���� </td>
		</tr>
		<tr>
			<td bgcolor="#CFEAEB"><font color="#FF0000">*</font>�̸���</td>
			<td bgcolor="#E8E8E8">
		<input name="email" id="email" type="text" value="<? echo $rs[email];?>; size="30">
			��)userid@domain.com</td>
		</tr>
		<tr>
			<td bgcolor="#CFEAEB">&nbsp;&nbsp;&nbsp;����� ��</td>
			<td bgcolor="#E8E8E8">
		<textarea name="content" id="content" cols="50" rows="10" wrap="VIRTUAL"><? echo $rs[content];?></textarea>
		</td>
		</tr>
	</table>
	<br>
	<table width="500" height="40" border="0" align="center" cellpadding="0" cellspacing="0" bgcolor="CFEAEB" style="border:0px #333333 solid; border-bottom-width:3px;">
		<tr>
		<td aligb="center">
		<input name="rowid" id="rowid" type="hidden" value="<? echo $rowid;?>">
		<input type="submit" name="Submit" value="�����մϴ�.">
		<input type="reset" name="Reset" value="���">
			</td>
		</tr>
		</table>
	</form>

	<script>
	function checkForm(theForm) {
		if (theForm.name.value==""){
			alert("�̸��� �Է��ϼ���.");
			theForm.name.focus();
			return false;
		} else if (theForm.email.value==""){
			alert("�̸����� �Է��ϼ���.");
			theForm.email.focus();
			return false;
		} else {
			return true;
		}
}
	
</script>
</body>
</html>